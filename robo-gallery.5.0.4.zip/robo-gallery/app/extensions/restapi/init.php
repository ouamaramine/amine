<?php 
/* @@copyright@ */

defined( 'WPINC' ) || exit;

include_once plugin_dir_path( __FILE__ ).'restapi.php';

include_once plugin_dir_path(__FILE__) . 'rest.utils.php';

include_once plugin_dir_path(__FILE__) . 'rest.options.php';

include_once plugin_dir_path(__FILE__) . 'endpoints/class.rest.controller.php';
include_once plugin_dir_path(__FILE__) . 'endpoints/class.rest.options.controller.php';

include_once plugin_dir_path(__FILE__) . 'models/class.rest.gallery.model.php';

include_once plugin_dir_path(__FILE__) . 'fields/class.gallery.fields.controller.php';

include_once plugin_dir_path( __FILE__ ).'class.restapi.php';






