<?php

?>
<div id="rbs-addons-confirm-dialog"  style="display: none;" data-slug="<?php echo $slug; ?>">
	<p>
		<?php _e('Please confirm that you wish to install new Add-on:','robo-gallery'); ?>
		<strong><?php echo $title;?></strong>
	</p>
</div>