<?php 
/* @@copyright@ */

if ( ! defined( 'WPINC' ) ) exit;

include_once plugin_dir_path( __FILE__ ).'class.key.php';