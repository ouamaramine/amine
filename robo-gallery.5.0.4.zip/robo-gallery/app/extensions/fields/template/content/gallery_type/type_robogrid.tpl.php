<div id="roboGalleryThemeTypeDiv">
	<img class="type-logo" src="<?php echo ROBO_GALLERY_URL; ?>app/extensions/galleryType/build/grids/robogrid_active.svg" style="width: 100px; height: 100px; margin: 20px 20px 20px 0; padding: 0; " />
	<h4><?php _e("Gallery Fusion Grid", 'robo-gallery'); ?></h4>
	<!--<p>
		<?php _e("Type", 'robo-gallery'); ?>:<?php echo rbsGalleryUtils::getFullSourceGallery(); ?>
	</p>-->
	<p>
	 <?php _e("
	 A next-generation gallery experience! Fusion Grid brings dynamic layouts,
	 smooth animations, and ultimate flexibility to showcase your images like never before.
	 Create stunning albums with interactive hovers, seamless mobility,
	 and innovative designs - all in one powerful gallery.", 'robo-gallery'); ?>
	</p>
</div>

